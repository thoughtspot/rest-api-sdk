
# E Format

## Structure

`EFormat`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `formatPattern` | `string \| undefined` | Optional | Represents the acceptable formats |

## Example (as JSON)

```json
{
  "formatPattern": null
}
```

