
# Visibility Enum

Visibility of the user account

## Enumeration

`VisibilityEnum`

## Fields

| Name |
|  --- |
| `dEFAULT` |
| `nONSHARABLE` |
| `sHARABLE` |

