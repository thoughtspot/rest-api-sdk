
# Group Properties

## Structure

`GroupProperties`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string \| undefined` | Optional | Username of the auther of user account |
| `id` | `string \| undefined` | Optional | GUID of the auther of user account |

## Example (as JSON)

```json
{
  "name": null,
  "id": null
}
```

