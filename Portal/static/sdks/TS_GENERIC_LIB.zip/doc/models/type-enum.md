
# Type Enum

Indicates the type of user account

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `uNKNOWN` |
| `lDAPUSER` |
| `sAMLUSER` |
| `oIDCUSER` |
| `lOCALUSER` |
| `lDAPGROUP` |
| `lOCALGROUP` |
| `tENANTGROUP` |

