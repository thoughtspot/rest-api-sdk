
# Error Response Error

## Structure

`ErrorResponseError`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `errorType` | `string \| undefined` | Optional | Represents the acceptable formats |

## Example (as JSON)

```json
{
  "errorType": null
}
```

