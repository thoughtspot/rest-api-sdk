
# Api Rest V2 Session Login Request

## Structure

`ApiRestV2SessionLoginRequest`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `userName` | `string` | Required | - |
| `password` | `string` | Required | - |
| `rememberMe` | `boolean \| undefined` | Optional | - |
| `tokenType` | [`TokenTypeEnum \| undefined`](/doc/models/token-type-enum.md) | Optional | - |

## Example (as JSON)

```json
{
  "userName": "userName2",
  "password": "password4",
  "rememberMe": null,
  "tokenType": null
}
```

