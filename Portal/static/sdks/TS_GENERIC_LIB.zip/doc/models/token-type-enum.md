
# Token Type Enum

## Enumeration

`TokenTypeEnum`

## Fields

| Name |
|  --- |
| `cookie` |
| `bearer` |

