
# E Format

## Structure

`EFormat`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `FormatPattern` | `String` | Optional | Represents the acceptable formats | String getFormatPattern() | setFormatPattern(String formatPattern) |

## Example (as JSON)

```json
{
  "formatPattern": null
}
```

