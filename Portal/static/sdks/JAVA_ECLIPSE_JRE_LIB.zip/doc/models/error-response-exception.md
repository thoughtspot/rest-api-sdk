
# Error Response Exception

## Structure

`ErrorResponseException`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `ErrorType` | `String` | Optional | Represents the acceptable formats | String getErrorType() | setErrorType(String errorType) |

## Example (as JSON)

```json
{
  "errorType": null
}
```

