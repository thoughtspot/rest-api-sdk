
# Visibility Enum

Visibility of the user account

## Enumeration

`VisibilityEnum`

## Fields

| Name |
|  --- |
| `DEFAULT` |
| `NONSHARABLE` |
| `SHARABLE` |

