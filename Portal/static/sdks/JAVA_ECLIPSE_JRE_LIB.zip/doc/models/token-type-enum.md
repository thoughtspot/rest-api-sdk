
# Token Type Enum

## Enumeration

`TokenTypeEnum`

## Fields

| Name |
|  --- |
| `Cookie` |
| `Bearer` |

