
# Modified Properties

## Structure

`ModifiedProperties`

## Fields

| Name | Type | Tags | Description | Getter | Setter |
|  --- | --- | --- | --- | --- | --- |
| `Name` | `String` | Optional | Username of the user which last modified the user account details | String getName() | setName(String name) |
| `Id` | `String` | Optional | GUID of the user which last modified the user account details | String getId() | setId(String id) |

## Example (as JSON)

```json
{
  "name": null,
  "id": null
}
```

