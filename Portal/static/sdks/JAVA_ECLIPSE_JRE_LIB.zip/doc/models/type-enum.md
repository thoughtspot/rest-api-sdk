
# Type Enum

Indicates the type of user account

## Enumeration

`TypeEnum`

## Fields

| Name |
|  --- |
| `UNKNOWN` |
| `LDAPUSER` |
| `SAMLUSER` |
| `OIDCUSER` |
| `LOCALUSER` |
| `LDAPGROUP` |
| `LOCALGROUP` |
| `TENANTGROUP` |

