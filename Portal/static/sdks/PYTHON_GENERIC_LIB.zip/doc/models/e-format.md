
# E Format

## Structure

`EFormat`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `format_pattern` | `string` | Optional | Represents the acceptable formats |

## Example (as JSON)

```json
{
  "formatPattern": null
}
```

