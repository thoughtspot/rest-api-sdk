
# Token Type Enum

## Enumeration

`TokenTypeEnum`

## Fields

| Name |
|  --- |
| `COOKIE` |
| `BEARER` |

