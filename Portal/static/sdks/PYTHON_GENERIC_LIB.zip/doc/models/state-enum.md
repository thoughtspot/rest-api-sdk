
# State Enum

Indicates if the user account is active or inactive

## Enumeration

`StateEnum`

## Fields

| Name |
|  --- |
| `ACTIVE` |
| `IN_ACTIVE` |

