
# Author Properties

## Structure

`AuthorProperties`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `name` | `string` | Optional | Username of the auther of user account |
| `id` | `string` | Optional | GUID of the auther of user account |

## Example (as JSON)

```json
{
  "name": null,
  "id": null
}
```

