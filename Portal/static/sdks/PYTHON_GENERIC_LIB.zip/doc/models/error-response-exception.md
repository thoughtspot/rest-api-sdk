
# Error Response Exception

## Structure

`ErrorResponseException`

## Fields

| Name | Type | Tags | Description |
|  --- | --- | --- | --- |
| `error_type` | `string` | Optional | Represents the acceptable formats |

## Example (as JSON)

```json
{
  "errorType": null
}
```

